﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Final._2021.WinFormsApp
{
    public partial class FrmListado : Form
    {
        List<Entidades.Auto> lista;

        public FrmListado()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
        }

        ///
        /// Punto 3 - Obtener y mostrar todos los autos de la BD
        ///
        private void FrmListado_Load(object sender, EventArgs e)
        {
            this.lista = Entidades.ADO.ObtenerTodos();
            this.lstListado.DataSource = this.lista;
        }

        ///
        /// Punto 4 - Agregar un nuevo auto a la BD. Utilizar FrmAuto
        ///
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            ///
            /// Punto 8-a - Capturar excepción si está repetido.
            ///
        }

        ///
        /// Punto 5 - Modificar auto seleccionado en la BD. Reutilizar FrmAuto
        ///
        private void btnModificar_Click(object sender, EventArgs e)
        {
            
        }

        ///
        /// Punto 6 - Eliminar auto seleccionado de la BD. Reutilizar FrmAuto.
        ///
        private void btnEliminar_Click(object sender, EventArgs e)
        {
        
        }

        ///
        /// Punto 8-b - Capturar evento ColorExiste y escribir en log
        ///
        private void Manejador_colorExistente(object sender, EventArgs e)
        {
            bool todoOK = false;//Reemplazar por la llamada al método de clase ManejadoraTexto.EscribirArchivo

            MessageBox.Show("Color repetido!!!");

            if (todoOK)
            {
                MessageBox.Show("Se escribió correctamente!!!");
            }
            else
            {
                MessageBox.Show("No se pudo escribir!!!");
            }
        }
    }
}
