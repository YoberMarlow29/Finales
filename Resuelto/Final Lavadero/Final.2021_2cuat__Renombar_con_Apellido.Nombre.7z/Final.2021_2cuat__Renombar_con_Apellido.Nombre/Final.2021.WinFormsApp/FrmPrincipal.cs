﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Final._2021.WinFormsApp
{
    ///Agregar manejo de excepciones en TODOS los lugares críticos!!!


    public partial class FrmPrincipal : Form
    {
        protected Task hilo;

        public FrmPrincipal()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        ///
        /// Punto 10 - Iniciar hilo
        ///
        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            this.Text = "Cambiar por su apellido y nombre";
            MessageBox.Show(this.Text);

            ///Se inicia el hilo

        }

        ///
        /// Punto 3 - FrmListado
        /// 
        private void listadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmListado frm = new FrmListado();
            frm.StartPosition = FormStartPosition.CenterScreen;

            frm.Show(this);
        }

        ///
        /// Punto 9
        ///
        private void verLogAutosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DialogResult rta = DialogResult.Cancel;///Reemplazar por la llamada al método correspondiente del OpenFileDialog

            if (rta == DialogResult.OK)
            {
                ///Mostrar el contenido en txtAutosLog
            }
        }

        ///PARA ACTUALIZAR LISTADO DESDE BD EN HILO
        ///NOTA: propiedades BackColor (fondo) y ForeColor (fuente)
        ///colores: 
        ///System.Drawing.Color.Black (negro)
        ///System.Drawing.Color.White (blanco)
        public void ActualizarListadoAutosBD(object param)
        {

        }
    }
}
