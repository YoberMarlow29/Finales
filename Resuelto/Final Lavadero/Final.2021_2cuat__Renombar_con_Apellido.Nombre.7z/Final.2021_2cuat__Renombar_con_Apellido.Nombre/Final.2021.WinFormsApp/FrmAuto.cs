﻿using System.Windows.Forms;

namespace Final._2021.WinFormsApp
{
    public partial class FrmAuto : Form
    {
        private Entidades.Auto auto;

        public Entidades.Auto AutoDelFormulario
        {
            get { return this.auto; }
        }

        public FrmAuto()
        {
            InitializeComponent();
        }

        /// Crar una instancia de tipo Auto
        /// Establecer como valor del atributo auto
        private void btnAceptar_Click(object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancelar_Click(object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
